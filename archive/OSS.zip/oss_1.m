%define params for joints

%Define joint 1
J1.I =  1.00; %inertia [kgm^2]
J1.m =  10.0; %mass [kg]
J1.d =  1.00; %length [m]
J1.xc=  0.50; %x center coord [m]
J1.yc=  0.00; %y center coord [m]
J1.s =  0.10; %max static friction torque [Nm]
J1.f =  0.01; %dynamic friction coeff [W-1]
J1.um=  -1.00; %min steering torque [Nm]
J1.uM=  1.00; %max steering torque [Nm]

%Define joint 2
J2.I =  1.00; %inertia [kgm^2]
J2.m =  5.0; %mass [kg]
J2.d =  0.70; %length [m]
J2.xc=  0.35; %x center coord [m]
J2.yc=  0.00; %y center coord [m]
J2.s =  0.10; %max static friction torque [Nm]
J2.f =  0.01; %dynamic friction coeff [W-1]
J2.um=  -1.00; %min steering torque [Nm]
J2.uM=  1.00; %max steering torque [Nm]

%solve model with ode45
Tsim = 100;
sfreq = 1000;

%time vector for u
t = linspace(0, Tsim, Tsim*sfreq+1);

u =  [sin(2*t) ; -sin(t)]';

x0 = [0 0 0 0];

[tout, xout] = solve45(x0, u, Tsim, sfreq, J1, J2);

pos = simpleKin(xout, J1, J2);

figure(1);
plot(pos(1,:),pos(2,:), "k");
hold on;
grid();
plot(pos(1,1),pos(2,1), "b*");

animate(pos, J1, J2, sfreq);

%SCARA 2axis robot model
function dx = model(t, x, u, J1, J2)
    x = x(:);
    %calculate additional params 
    
    %Steiner reduced masses
    B = J2.m*J1.d*(J2.xc*cos(x(2)) - J2.yc*sin(x(2)));
    B2 = -J2.m*J1.d*(J2.xc*sin(x(2)) + J2.yc*cos(x(2)));
    
    %inertia matrix
    M_11 = J1.I + J2.I + J2.m*J1.d^2+2*B;
    M_12 = B;
    M_22 = J2.I;

    %Coriolis and radial forces
    V1 = B2*(2*x(3)*x(4)+ x(4)^2);
    V2 = -B2*x(3)^2;
    
    %friction 
    T1 = J1.s*tanh(10*x(3)) + J1.f*x(3);
    T2 = J2.s*tanh(10*x(4)) + J2.f*x(4);

    %build & inverse inertia matrix
    M = [M_11 M_12; M_12 M_22];
    Minv = inv(M);
    
    %build equations
    f0 = [  x(3); 
            x(4); 
            -Minv(1,1)*(V1+T1) - Minv(1,2)*(V2+T2);
            -Minv(1,2)*(V1+T1) - Minv(2,2)*(V2+T2);
         ];

    g1 = [  0;
            0;
            Minv(1,1);
            Minv(1,2);
         ];
    
    g2 = [  0;
            0;
            Minv(1,2);
            Minv(2,2);
         ];
    
    %calculate output
    dx = f0 + g1*u(1) + g2*u(2);
end

%Runge-Kutty solver
function [t,x] = solve45(x0, u, tf, sfreq, J1, J2)
    %rewrite inputs as horizontal
    x0 = x0(:);
    n = length(x0);

    %step num & size 
    Nt = ceil(tf*sfreq);
    h = tf/Nt;

    %declare matrices
    x = zeros(Nt+1, n);
    t = zeros(Nt+1, 1);
    x(1,:) = x0';

    xtmp = x0;
    tt = 0;

    tmp = zeros(n,1);
    dx1 = zeros(n,1);
    dx2 = zeros(n,1);
    dx3 = zeros(n,1);
    dx4 = zeros(n,1);
    
    %solve 
    for i = 1:Nt
        dx1 = model(tt, xtmp, u(i,:), J1, J2);   tmp = xtmp+h/2*dx1; tt = tt+h/2;
        dx2 = model(tt, tmp, u(i,:), J1, J2);    tmp = xtmp+h/2*dx2; 
        dx3 = model(tt, tmp, u(i,:), J1, J2);    tmp = xtmp+h*dx3;   tt = tt+h/2;
        dx4 = model(tt, tmp, u(i,:), J1, J2);

        xtmp = xtmp + h/6*(dx1 + 2*dx2 + 2*dx3 + dx4);

        %write outputs
        x(i+1,:) = xtmp';
        t(i+1) = tt;
    end
end

%ode45 solver for discontinuities
function [t,x,uk,nseg] = dSolve45(tau, u, x0, sfreq, J1, J2)
    
    [ntau, nu] = size(u);   %get 
    n = length(x0);         %get 
    tau = [0;tau];

    %Get num of samples
    Nt = 1+sum(ceil(sfreq*diff(tau)));

    %
    x = zeros(Nt,n);    
    uk = zeros(Nt,nu);
    t = zeros(Nt, 1);
    nseg = zeros(ntau,1);
    k = 1;                  %starting sample

    for i = 1:ntau %for i-th continuous segment
        simt = tau(i+1) - tau(i); %get partial sim time
        [tseg,xseg] = solve45(x0,u(i,:)',simt,sfreq); %solve with i-th input
        x0 = xseg(end,:)'; %get next boundary
        Ni = ceil(sfreq*simt); %set samples num for current sim
        x(k:k+Ni-1,:) = xseg(1:end-1,:); %write new states
        t(k:k+Ni-1) = tau(i) + tseg(1:end-1,:); %write new time
        uk(k:k+Ni-1,:) = kron(u(k,:),ones(Ni,1));
        k = k+ni; 
    end

    x(end,:) = xseg(end,:); %set end state
    uk(end,:) = u(end,:); %set end input
    t(end) = tau(end); %set end time

end

%simple kinematics - visualize robot pos
function pos = simpleKin(Jdata, J1, J2)
    N = length(Jdata(:,1));
    pos = zeros(4,N);
    for i = 1:N
        Rx1 = [cos(Jdata(i,1)) -sin(Jdata(i,1));
               sin(Jdata(i,1)) cos(Jdata(i,1))];
        Rx2 = [cos(Jdata(i,2)) -sin(Jdata(i,2));
               sin(Jdata(i,2)) cos(Jdata(i,2))];
        pos(1:2,i) = Rx1*[J1.d;0] + Rx1*Rx2*[J2.d; 0];
        pos(3:4,i) = Rx1*[J1.d;0];
    end
end

%animate robot
function res = animate(pos, J1, J2, sfreq)

    N = length(pos(1,:));
    figure(2137);
    grid();
    hold on;
    plot(0,0,"k*",'LineWidth',3);
    j2plot = plot([pos(3,1) pos(1,1)],[pos(4,1) pos(2,1)], 'k*-', 'LineWidth',3);
    j1plot = plot([0 pos(3,1)],[0 pos(4,1)],'k','LineWidth',3);
    axis([-2 2 -2 2]);

    for i = 1:floor(sfreq/20):N
        j1plot.XData = [0 pos(3,i)];
        j1plot.YData = [0 pos(4,i)];
        j2plot.XData = [pos(3,i) pos(1,i)];
        j2plot.YData = [pos(4,i) pos(2,i)];
        drawnow 
    end

    res = 1;
end

