clear;close all;tauopt=[.15 .30 .40]';u=1.0*[1;-1;1];
x0=[0;0;0];xf=[pi;0;0];W=1000*eye(3);MDNS=300;
qh=@(tauopt) cost_fun(tauopt,u,x0,xf,W,MDNS);
nb=length(tauopt);b=0.0*ones(nb,1);A=-eye(nb);
for k=2:nb, A(k,k-1)=1;end %ograniczenia
options=optimoptions('fmincon');
options.SpecifyObjectiveGradient=true;
options.Display="iter";options.Algorithm="interior-point";
tauopt=fmincon(qh,tauopt,A,b,[],[],[],[],[],options);
[t,x,uk,nseg]=get_tx(tauopt,u,x0,MDNS);pf=-W*(x(end,:)'-xf);
p=rk4p(pf,t,x,uk);nt=length(t);hu=zeros(nt,1);
for k=1:nt
    hu(k)=get_hu(t(k),p(k,:)',x(k,:)',uk(k,:)');
end
hu=hu/max(abs(hu));
subplot(211);h=plot(t,x);set(h,"linewidth",2);
subplot(212);h=stairs(t,uk/max(uk));set(h,"linewidth",2);
hold on;h=plot(t,hu);grid;set(h,"linewidth",2);
axis([0 t(end) -1.1 1.1]);hold off

%%
function [q,g]=cost_fun(tau,u,x0,xf,W,MDNS)
    % xf - stan docelowy, W=W^T>0 - macierz wag
    %calkowanie rownania stanu
    [~,x]=get_tx(tau,u,x0,MDNS);
    % roznica pomiedzy stanem koncowym i docelowym
    dxend=x(end,:)'-xf;
    % funkcja celu
    q=tau(end)+0.5*dxend'*W*dxend;
    if nargout>1
        %opcjonalne obliczenie gradientu
        g=get_grad(tau,u,x0,xf,W,MDNS);
    end
end
function [t,x,uk,nseg]=get_tx(tau,u,x0,MDNS)
    [ntau,nu]=size(u);
    n=length(x0);
    tau=[0;tau];
    nt=1+sum(1+floor(MDNS*diff(tau)));
    x=zeros(nt,n);
    uk=zeros(nt,nu);
    t=zeros(nt,1);
    nseg=zeros(ntau,1);kk=1;
    for k=1:ntau
        [ttmp,xtmp]=rk4(x0,u(k,:)',tau(k+1)-tau(k),MDNS);% RK4
        x0=xtmp(end,:)';%warunek poczatkowy do nastepnego
        ni=1+floor(MDNS*(tau(k+1)-tau(k)));%liczba krokow
        x(kk:kk+ni-1,:)=xtmp(1:end-1,:);%zapis x
        t(kk:kk+ni-1)=tau(k)+ttmp(1:end-1,:);%zapis t
        uk(kk:kk+ni-1,:)=kron(u(k,:),ones(ni,1));%zapis uk
        kk=kk+ni;nseg(k)=kk;
    end
    x(end,:)=xtmp(end,:);% dodaje stan koncowy
    uk(end,:)=u(end,:);% dodaje sterowanie na koncu
    t(end)=tau(end);%dodaje czas koncowy
    % t-wektor czasow [0, t1, ..., tn],
end
function dp=prhs(t,x,u,p)
    %Adjoint equations
    dp=zeros(3,1);
    w0=9;ksi=0.01;tau=0.04;k=250;
    dp(1)=w0^2*cos(x(1))*p(2);
    dp(2)=-p(1)+2*ksi*w0*p(2);
    dp(3)=-k*p(2)+p(3)/tau;
end
function p=rk4p(pf,t,x,uk)
    nt=length(t);np=length(pf);x=flipud(x);uk=flipud(uk);
    t=t(end)-t;t=flipud(t);p=zeros(nt,np);p(1,:)=pf';
    tmp=zeros(np,1);ptmp=pf;tt=0;
    dp1=zeros(np,1);dp2=zeros(np,1);
    dp3=zeros(np,1);dp4=zeros(np,1);
    for k=1:nt-1
    h=t(k+1)-t(k);h_2=h/2;h_6=h/6;h_26=2*h_6;
    dp1=-prhs(tt,x(k,:)',uk(k+1,:)',ptmp);
    tmp=ptmp+h_2*dp1;tt=tt+h_2;
    x05=0.5*(x(k,:)+x(k+1,:))';
    dp2=-prhs(tt,x05,uk(k+1,:)',tmp);tmp=ptmp+h_2*dp2;
    dp3=-prhs(tt,x05,uk(k+1,:)',tmp);tmp=ptmp+h*dp3;tt=tt+h_2;
    dp4=-prhs(tt,x(k+1,:)',uk(k+1,:)',tmp);
    ptmp=ptmp+h_6*(dp1+dp4)+h_26*(dp2+dp3);
    p(k+1,:)=ptmp';
    end
    p=flipud(p);
end
function g=get_grad(tau,u,x0,xf,W,MDNS)
    %solve state equation, forward
    [t,x,uk,nseg]=get_tx(tau,u,x0,MDNS);
    %final cond. psi
    pf=-W*(x(end,:)'-xf);
    %solve adjoint equation, backward
    p=rk4p(pf,t,x,uk);
    ng=length(tau);g=zeros(ng,1);
        for k=1:ng-1
        hu=get_hu(tau(k),p(nseg(k),:)',x(nseg(k),:)',u(k+1,:)');
        %derrivative w.r.t. switching time
        g(k)=hu*(u(k+1)-u(k));
        end
    %derrivative w.r.t final time
    g(end)=1-pf'*rhs(tau(end),x(end,:)',u(end,:)');
end
function hu=get_hu(t,p,x,u)
    %funkcja przelaczajaca,
    %pochodna hamiltonianu wzgledem sterowania
    tau=0.04;hu=p(3)/tau;
end
function [t,x]=rk4(x0,u,tf,MDNS)
    x0=x0(:);u=u(:);n=length(x0);
    nt=1+floor(tf*MDNS);h=tf/nt;
    x=zeros(nt+1,n);t=zeros(nt+1,1);
    x(1,:)=x0';
    tmp=zeros(n,1);xtmp=x0;tt=0;
    dx1=zeros(n,1);dx2=zeros(n,1);
    dx3=zeros(n,1);dx4=zeros(n,1);
    h_2=h/2;h_6=h/6;h_26=2*h_6;
    for i=1:nt
        dx1=rhs(tt,xtmp,u);tmp=xtmp+h_2*dx1;tt=tt+h_2;
        dx2=rhs(tt,tmp,u);tmp=xtmp+h_2*dx2;
        dx3=rhs(tt,tmp,u);tmp=xtmp+h*dx3;tt=tt+h_2;
        dx4=rhs(tt,tmp,u);
        xtmp=xtmp+h_6*(dx1+dx4)+h_26*(dx2+dx3);
        x(i+1,:)=xtmp';t(i+1)=tt;
    end
end
function dx=rhs(t,x,u)
    dx=zeros(3,1);w0=9;ksi=0.01;tau=0.04;k=250;
    dx(1)=x(2);
    dx(2)=-w0^2*sin(x(1))-2*ksi*w0*x(2)+k*x(3);
    dx(3)=(u-x(3))/tau;
end
